         package:   codeWorks.py
          author:   Christian Rios <crios2703019@woonsocketschools.com> 
          author:   Eliana Louis Jean <elouisjean2718323@woonsocketschools.com> 
          author:   Maja Pisarek <mpisarek2709261@woonsocketschools.com>
            date:   2024.12.02
         version:   1.0 pre-alpha

     description: Your friend went missing leaving only a note, it is your duty to venture off and find them. On your adeventure you'll meet the kingdoms fiercest monsters and spirits. Do you have what it takes to save your friend? 

### This work © 2024 by Christian D Rios is licensed under CC BY-NC-SA 4.0